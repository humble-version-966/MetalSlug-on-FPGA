int main()
{
	int i = 0;
	volatile unsigned int *LED_PIO = (unsigned int*)0x40; //make a pointer to access the PIO block
	volatile unsigned int *SW	= (unsigned int*)0x60;
	volatile unsigned int *KEY1 = (unsigned int*)0x90;



	*LED_PIO = 0; //clear all LEDs
// ##### two separate functions #####
//	while ( (1+1) != 3) //infinite loop
//	{
//		for (i = 0; i < 100000; i++); //software delay
//		*LED_PIO |= 0x1; //set LSB
//		for (i = 0; i < 100000; i++); //software delay
//		*LED_PIO &= ~0x1; //clear LSB
//	}
//
//	while ( (1+1) != 3) //infinite loop
//	{
//		while (*KEY1 == 1)
//		{
//			i = 1;
//		}
//		*LED_PIO += *SW;
//		while (*KEY1 == 0)
//		{
//			i = 1;
//		}
//	}


// ##### one combined functions #####
	while ( (1+1) != 3) //infinite loop
	{
		for (i = 0; i < 100000; i++); //software delay
		*LED_PIO |= 0x1; //set LSB
		for (i = 0; i < 100000; i++); //software delay
		*LED_PIO &= ~0x1; //clear LSB
		if (*KEY1 == 0){
			while ( (1+1) != 3) //infinite loop
			{
				while (*KEY1 == 1)
				{
					i = 1;
				}
				*LED_PIO += *SW;
				while (*KEY1 == 0)
				{
					i = 1;
				}
			}
		}
	}

	return 1; //never gets here
}
